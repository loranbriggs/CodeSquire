//import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.util.*;
import java.util.regex.*;

public class Polynomials extends JApplet {

  String inputString1 = "3x^2 + 5x + 2";
  String inputString2 = "4x^2 + 2x + 3";
  String[] operations = { "addition", "subtraction", "multiplication", "evaluate", "derivative" };

  // GUI Objects
  JTextField jtfInput1 = new JTextField(20);
  JTextField jtfInput2 = new JTextField(20);
  JLabel     jlFofX    = new JLabel("x = ");
  JTextField jtfX      = new JTextField(10);
  JComboBox  jcbOperations = new JComboBox(operations);
  JButton    jbCompute = new JButton("Compute");
  JButton    jbExit= new JButton("Exit");
  JLabel     jlOutput = new JLabel();

  public Polynomials() {
    // paneles
    JPanel inputsPanel = new JPanel( new GridLayout(3,1) );
    inputsPanel.add(jtfInput1);
    jtfInput1.setText(inputString1);
    inputsPanel.add(jtfInput2);
    jtfInput2.setText(inputString2);
    JPanel fOfXPanel = new JPanel( new GridLayout(1,2) );
    fOfXPanel.add(jlFofX);
    fOfXPanel.add(jtfX);
    jlFofX.setVisible(false);
    jtfX.setVisible(false);
    inputsPanel.add(fOfXPanel);
    inputsPanel.setBorder( new TitledBorder("Inputs") );

    JPanel operationsPanel = new JPanel( new GridLayout(2,1) );
    operationsPanel.add(jcbOperations);
    operationsPanel.add(jbCompute);
    operationsPanel.setBorder( new TitledBorder("Operations") );

    JPanel outputPanel = new JPanel();
    outputPanel.add(jlOutput);
    outputPanel.setBorder( new TitledBorder("Output") );
    
    JPanel bottomPanel = new JPanel( new GridLayout(2,1) );
    bottomPanel.add(outputPanel);
    bottomPanel.add(jbExit);

    JPanel mainPanel = new JPanel();
    mainPanel.add(inputsPanel);
    mainPanel.add(operationsPanel);

    // Add panels to frame
    add(mainPanel, BorderLayout.CENTER);
    add(bottomPanel, BorderLayout.SOUTH);

    // Register Listeners
    jbCompute.addActionListener( new ComputeListener() );
    jbExit.addActionListener( new ExitListener() );
    jcbOperations.addItemListener( new OperationListener() );
  }

  // Define Listeners
  private class ComputeListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      try {
        if ( jcbOperations.getSelectedItem().equals("addition") ) {
          jlOutput.setText( Addition( jtfInput1.getText(), jtfInput2.getText() ) );
        }
        else if ( jcbOperations.getSelectedItem().equals("subtraction") )
          jlOutput.setText( Subtraction( jtfInput1.getText(), jtfInput2.getText() ) );
        else if ( jcbOperations.getSelectedItem().equals("multiplication") )
          jlOutput.setText( Multiplication( jtfInput1.getText(), jtfInput2.getText() ) );
        else if ( jcbOperations.getSelectedItem().equals("evaluate") )
          jlOutput.setText( "f(x) = " + Evaluate( jtfInput1.getText(), jtfX.getText() ) );
        else if ( jcbOperations.getSelectedItem().equals("derivative") )
          jlOutput.setText( Derivative(jtfInput1.getText()) );
      } catch ( IllegalArgumentException exepction ) {
        jlOutput.setText("Illegal input, try again ");
      }
    }
  }

  private class ExitListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      System.exit(0);
    }
  }

  private class OperationListener implements ItemListener {
    public void itemStateChanged(ItemEvent e) {
      if ( jcbOperations.getSelectedItem().equals("addition") ||
           jcbOperations.getSelectedItem().equals("subtraction") ||
           jcbOperations.getSelectedItem().equals("multiplication") ) {
        jlFofX.setVisible(false);
        jtfX.setVisible(false);
        jtfInput2.setVisible(true);
      } else if ( jcbOperations.getSelectedItem().equals("evaluate") ) {
        jlFofX.setVisible(true);
        jtfX.setVisible(true);
        jtfInput2.setVisible(false);
      } else if ( jcbOperations.getSelectedItem().equals("derivative") ) {
        jlFofX.setVisible(false);
        jtfX.setVisible(false);
        jtfInput2.setVisible(false);
      }
    }
  }

  // Define Methods
  private String Addition( String input1, String input2 ) throws IllegalArgumentException  {
    LinkedList<Term> terms1 = stringToList( input1 );
    LinkedList<Term> terms2 = stringToList( input2 );
    Polynomial poly1 = new Polynomial(terms1);
    Polynomial poly2 = new Polynomial(terms2);
    return addSpaces( poly1.add(poly2).toString() );
  }

  private String Subtraction( String input1, String input2 ) throws IllegalArgumentException  {
    LinkedList<Term> terms1 = stringToList( input1 );
    LinkedList<Term> terms2 = stringToList( input2 );
    Polynomial poly1 = new Polynomial(terms1);
    Polynomial poly2 = new Polynomial(terms2);
    return addSpaces( poly1.sub(poly2).toString() );
  }

  private String Multiplication( String input1, String input2 ) throws IllegalArgumentException  {
    LinkedList<Term> terms1 = stringToList( input1 );
    LinkedList<Term> terms2 = stringToList( input2 );
    Polynomial poly1 = new Polynomial(terms1);
    Polynomial poly2 = new Polynomial(terms2);
    return addSpaces( poly1.mul(poly2).toString() );
  }

  private double Evaluate( String input1, String input2 ) throws IllegalArgumentException  {
    LinkedList<Term> terms1 = stringToList( input1 );
    double d = Double.parseDouble( input2 );
    Polynomial poly1 = new Polynomial(terms1);
    return poly1.eval(d);
  }

  private String Derivative( String input1 ) throws IllegalArgumentException  {
    LinkedList<Term> terms1 = stringToList( input1 );
    Polynomial poly1 = new Polynomial(terms1);
    return addSpaces( poly1.der().toString() );
  }

  private String removeSpaces(String s) {
    return s.replaceAll(" ", "");
  }

  private String addSpaces(String s) {
    // add spaces between '+' and '-'
    s = s.replaceAll("\\+", "  +  ");
    s = s.replaceAll("-", "  -  ");
    // remove leading '+' sign
    if ( s.substring(0,5).equals("  +  ") )
      s = s.substring(5);
    return s;
  }

  private LinkedList<Term> stringToList( String s ) {
    String var   = "x";
    for ( int i = 0; i < s.length(); i++) {
      if ( Character.isLetter( s.charAt(i) ) )
        var = s.charAt(i) + "";
      break;
    }
    // converts a string to a list of terms
    LinkedList<Term> terms = new LinkedList<Term>(); 
    s = removeSpaces(s);
    // split by operand '+' or '-'
    String[] tokens = s.split("(?=-|\\+)");
    for ( String token : tokens ) {
      double coeff = 0;
      int expon    = 0;
      if ( token.equals("") || token.equals(" ") )
        continue;
      Pattern p = Pattern.compile("[a-zA-Z]");
      Matcher m = p.matcher(token);
      if ( m.find() ) {
        int index = m.start();
        var = "" + token.charAt(index);
        String coeffString = token.substring(0, index).trim();
        if ( coeffString.equals("") || coeffString.equals(" ") || coeffString.equals("+") ) {
          coeff = 1;
        }
        else if ( coeffString.equals("-") ) {
          coeff = -1;
        } else {
          coeff = Double.parseDouble( token.substring(0, index) );
        }
        if (index < token.length() - 1) {
          expon = Integer.parseInt( token.substring( index + 2 ) );
        } else {
          expon = 1;
        }
      } else {
        coeff = Double.parseDouble(token);
      }
      terms.add( new Term( coeff, var, expon ) );
    }
    return terms;
  }

  public static void main(String[] args) {
    JFrame frame = new JFrame();
    Polynomials applet = new Polynomials();
    frame.add(applet);
    frame.setTitle("Polynomials");
    frame.setSize(500, 250);
    frame.setLocationRelativeTo(null); // Center the frame
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);
  }
}
