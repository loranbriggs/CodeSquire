public class Term {
  private double coefficient;
  private int exponent;
  private String variable;

  public Term() {
    this(1.0, "x", 1);
  }

  public Term(double coe, String var, int exp) {
    coefficient = coe;
    variable = var;
    exponent = exp;
  }

  public double getCoefficient() {
    return coefficient;
  }

  public String getVariable() {
    return variable;
  }

  public int getExponent() {
    return exponent;
  }

  public void setCoefficient(double coe) {
    coefficient = coe;
  }

  public void setVariable(String var) {
    variable = var;
  }

  public void setExponent(int exp) {
    exponent = exp;
  }

  public Term add(Term term2) throws IllegalArgumentException {
    if ( this.exponent == term2.exponent && this.variable.equals(term2.variable) ) {
      return new Term( (this.coefficient + term2.coefficient), this.variable, this.exponent );
    }
    else {
      throw new IllegalArgumentException();
    }
  }

  public Term sub(Term term2) throws IllegalArgumentException {
    if ( this.exponent == term2.exponent && this.variable.equals(term2.variable) ) {
      return new Term( (this.coefficient - term2.coefficient), this.variable, this.exponent );
    }
    else {
      throw new IllegalArgumentException();
    }
  }

  public Term mul(Term term2) throws IllegalArgumentException {
    if ( this.getVariable().equals(term2.getVariable()) ) {
      return new Term( (this.coefficient * term2.coefficient),
                       (this.variable),
                       (this.exponent + term2.exponent) );
    } else {
      return new Term( (this.coefficient * term2.coefficient),
                       (this.variable + term2.variable),
                       (this.exponent + term2.exponent) );
    }
  }

  public double eval(double d) throws IllegalArgumentException {
    return Math.pow( d, exponent) * coefficient;
  }

  public Term der() throws IllegalArgumentException {
    if ( this.exponent != 0 )
      return new Term( this.coefficient * this.exponent, this.variable, this.exponent - 1 );
    else
      return new Term( 0, this.variable, 0 );
  }

  public String toString() {
    String coeffString;
    if ( coefficient - Math.floor(coefficient) < 1e-8 )
      coeffString = "" + (int)coefficient;
    else
      coeffString = "" + coefficient;
    if ( coefficient > 0 )
      coeffString = "+" + coeffString;
    if ( coefficient == 1 )
      coeffString = "+";
    if ( coefficient == 1 && exponent == 0 )
      coeffString = "+1";
    if ( coefficient == -1 )
      coeffString = "-";
    if ( coefficient == -1 && exponent == 0 )
      coeffString = "-1";

    String varString;
    if ( exponent == 0 )
      varString = "";
    else if ( exponent == 1 )
      varString = variable;
    else
      varString = variable + '^' + exponent;

    if ( coefficient == 0 )
      return "";
    else
      return coeffString + varString;

  }
}
