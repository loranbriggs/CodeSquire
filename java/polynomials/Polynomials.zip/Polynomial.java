import java.util.*;

public class Polynomial {
  private LinkedList<Term> poly = new LinkedList<Term>();

  public Polynomial() {
  }

  public Polynomial(Term t) {
    poly.add(t);
  }

  public Polynomial(LinkedList<Term> c) {
    ListIterator<Term> termIterator = c.listIterator();
    while ( termIterator.hasNext() ) {
      poly.add( termIterator.next() );
    }
  }

  class TermComparator implements Comparator<Term> {
    public int compare(Term t1, Term t2) {
      Integer expon1 = t1.getExponent();
      Integer expon2 = t2.getExponent();

      return expon1.compareTo(expon2);
    }
  }

  public Polynomial add(Polynomial p2) throws IllegalArgumentException {
    ListIterator<Term> p2TermIterator = p2.poly.listIterator();
    boolean foundLikedTerm;
    while ( p2TermIterator.hasNext() ) {
      foundLikedTerm = false;
      int indexP2 = p2TermIterator.nextIndex();
      Term tempP2 = p2TermIterator.next();
      ListIterator<Term> thisTermIterator = this.poly.listIterator();
      while ( thisTermIterator.hasNext() ) {
        int indexThis = thisTermIterator.nextIndex();
        Term tempThis = thisTermIterator.next();
        if ( tempThis.getExponent() == tempP2.getExponent() && 
             tempThis.getVariable().equals( tempP2.getVariable() ) ) {
          this.poly.set(indexThis, tempThis.add(tempP2) );
          foundLikedTerm = true;
        }
      }
      if ( !foundLikedTerm )
        this.poly.add( tempP2 );
    }
    return this.simplify();
  }

  public Polynomial sub(Polynomial p2) throws IllegalArgumentException {
    ListIterator<Term> p2TermIterator = p2.poly.listIterator();
    boolean foundLikedTerm;
    while ( p2TermIterator.hasNext() ) {
      foundLikedTerm = false;
      int indexP2 = p2TermIterator.nextIndex();
      Term tempP2 = p2TermIterator.next();
      ListIterator<Term> thisTermIterator = this.poly.listIterator();
      while ( thisTermIterator.hasNext() ) {
        int indexThis = thisTermIterator.nextIndex();
        Term tempThis = thisTermIterator.next();
        if ( tempThis.getExponent() == tempP2.getExponent() && 
             tempThis.getVariable().equals( tempP2.getVariable() ) ) {
          this.poly.set(indexThis, tempThis.sub(tempP2) );
          foundLikedTerm = true;
        }
      }
      if ( !foundLikedTerm ) {
        Term newTemp =
          new Term( 0 - tempP2.getCoefficient(), tempP2.getVariable(), tempP2.getExponent() );
        this.poly.add( newTemp );
      }
    }
    return this.simplify();
  }

  public Polynomial mul(Polynomial p2) throws IllegalArgumentException {
    Polynomial newPoly = new Polynomial();
    ListIterator<Term> thisTermIterator = this.poly.listIterator();
    while ( thisTermIterator.hasNext() ) {
      Term temp1 = thisTermIterator.next();
      ListIterator<Term> p2TermIterator = p2.poly.listIterator();
      while ( p2TermIterator.hasNext() ) {
        Term temp2 = p2TermIterator.next();
        newPoly.poly.add( temp1.mul(temp2) );
      }
    }
    return newPoly.simplify();
  }

  public double eval(double d) throws IllegalArgumentException  {
    double newDouble = 0;
    ListIterator<Term> thisTermIterator = this.poly.listIterator();
    while ( thisTermIterator.hasNext() ) {
      newDouble += thisTermIterator.next().eval(d);
    }
    return newDouble;
  }

  public Polynomial der() throws IllegalArgumentException  {
    Polynomial newPoly = new Polynomial();
    ListIterator<Term> thisTermIterator = this.poly.listIterator();
    while ( thisTermIterator.hasNext() ) {
      Term temp1 = thisTermIterator.next();
      newPoly.poly.add( temp1.der() );
    }
    return newPoly.simplify();
  }

  public Polynomial simplify() {
    ListIterator<Term> TermIterator1 = this.poly.listIterator();
    while ( TermIterator1.hasNext() ) {
      int index1 = TermIterator1.nextIndex();
      Term temp1 = TermIterator1.next();
      ListIterator<Term> TermIterator2 =
        this.poly.listIterator( TermIterator1.nextIndex() );
      while ( TermIterator2.hasNext() ) {
        int index2 = TermIterator2.nextIndex();
        Term temp2 = TermIterator2.next();
        if ( temp1.getExponent() == temp2.getExponent() && 
             temp1.getVariable().equals( temp2.getVariable() ) ) {
          this.poly.set(index1, temp1.add(temp2) );
          this.poly.set(index2, temp2.sub(temp2) );
        }
      }
    }
    Collections.sort( this.poly, new TermComparator() );
    Collections.reverse( this.poly );
    return this;
  }

  public String toString() {
    String returnString = "";
    ListIterator<Term> thisTermIterator = this.poly.listIterator();
    while ( thisTermIterator.hasNext() ) {
      Term temp1 = thisTermIterator.next();
      returnString += temp1.toString();
    }
    return returnString;
  }

}
