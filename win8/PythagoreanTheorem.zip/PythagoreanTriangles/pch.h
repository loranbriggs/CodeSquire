﻿//
// pch.h
// Header for standard system include files.
//

#pragma once

#include <collection.h>
#include "App.xaml.h"
//The following lines are added by you
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <iostream> 
#include <sstream> 
//End of the lines included by you
