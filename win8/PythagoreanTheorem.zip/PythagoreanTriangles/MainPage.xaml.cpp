﻿//
// MainPage.xaml.cpp
// Implementation of the MainPage class.
//

#include "pch.h"
#include "MainPage.xaml.h"

using namespace PythagoreanTriangles;

using namespace Platform;
using namespace Windows::Foundation;
using namespace Windows::Foundation::Collections;
using namespace Windows::UI::Xaml;
using namespace Windows::UI::Xaml::Controls;
using namespace Windows::UI::Xaml::Controls::Primitives;
using namespace Windows::UI::Xaml::Data;
using namespace Windows::UI::Xaml::Input;
using namespace Windows::UI::Xaml::Media;
using namespace Windows::UI::Xaml::Navigation;

using namespace std;

boolean aEmpty, bEmpty, cEmpty = true;
double A, B, C;
// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

MainPage::MainPage()
{
	InitializeComponent();
}

/// <summary>
/// Invoked when this page is about to be displayed in a Frame.
/// </summary>
/// <param name="e">Event data that describes how this page was reached.  The Parameter
/// property is typically used to configure the page.</param>
void MainPage::OnNavigatedTo(NavigationEventArgs^ e)
{
	(void) e;	// Unused parameter
}


void PythagoreanTriangles::MainPage::calcButton_Click(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e)
{
  
  String^ LegA = aField->Text;
  wstring wLegA( LegA->Data()); 
  if (wLegA.empty())
    aEmpty = true;
  else {
    aEmpty = false;
    wstringstream convertorA;
    convertorA << wLegA;
    convertorA >> A;
  }

  String^ LegB = bField->Text;
  wstring wLegB( LegB->Data()); 
  if (wLegB.empty())
    bEmpty = true;
  else {
    bEmpty = false;
    wstringstream convertorB;
    convertorB << wLegB;
    convertorB >> B;
  }
  
  String^ LegC = cField->Text;
  wstring wLegC( LegC->Data()); 
  if (wLegC.empty())
    cEmpty = true;
  else {
    cEmpty = false;
    wstringstream convertorC;
    convertorC << wLegC;
    convertorC >> C;
  }

  if ( aEmpty && bEmpty && cEmpty )
    errorField->Text = "All three cannont be blank";
  else if ( aEmpty && bEmpty )
    errorField->Text = "Two cannont be blank";
  else if ( aEmpty && cEmpty )
    errorField->Text = "Two cannont be blank";
  else if ( bEmpty && cEmpty )
    errorField->Text = "Two cannont be blank";
  else if ( aEmpty ) {
    errorField->Text = "";
    A = sqrt( pow(C,2) - pow(B,2) );
    if ( A - floor(A) < 1e-8 ) // test if an integer
      aField->Text = "" + A;
    else
      aField->Text = "" + A + " = sqrt(" + pow(A,2) + ")"; // dispay the square
  }
  else if ( bEmpty ) {
    errorField->Text = "";
    B = sqrt( pow(C,2) - pow(A,2) );
    if ( B - floor(B) < 1e-8 ) // test if an integer
      bField->Text = "" + B;
    else
      bField->Text = "" + B + " = sqrt(" + pow(B,2) + ")";
  }
  else if ( cEmpty ) {
    errorField->Text = "";
    C = sqrt( pow(A,2) + pow(B,2) );
    if ( C - floor(C) < 1e-8 ) // test if an integer
      cField->Text = "" + C;
    else
      cField->Text = "" + C + " = sqrt(" + pow(C,2) + ")";
  }
}
